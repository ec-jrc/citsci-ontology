List of files:
- Attribute description: Inventory of environmental citizen science projects - Attributes for the inventory.pdf
- Inventory of environmental citizen science projects (CSV format): Inventory of environmental citizen science projects_anonymised.csv
- Inventory of environmental citizen science projects (XLSX format): Inventory of environmental citizen science projects_anonymised.xlsx