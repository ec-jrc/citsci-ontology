List of files:
- Inventory of environmental citizen science projects (JSON-LD): Inventory of environmental citizen science projects_anonymised.json
- JSON Schema for the Inventory of environmental citizen science projects in JSON-LD (JSON format): Inventory_SCHEMA_JSON-LD.json