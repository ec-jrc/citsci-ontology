List of files:
- Inventory of environmental citizen science projects in CSV: Inventory of environmental citizen science projects in CSV.zip
- Inventory of environmental citizen science projects in JSON: Inventory of environmental citizen science projects in JSON.zip
- Inventory of environmental citizen science projects in JSON-LD: Inventory of environmental citizen science projects in JSON - LD.zip